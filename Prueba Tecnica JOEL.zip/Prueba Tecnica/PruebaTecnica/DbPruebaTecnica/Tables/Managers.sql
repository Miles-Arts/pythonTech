﻿CREATE TABLE [dbo].[Managers]
(
	[ManagerId] INT IDENTITY(1,1) NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(50) NOT NULL
)
