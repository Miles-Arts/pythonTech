﻿namespace PruebaTecnica.Core.DTOS
{
    public class BalanceManagersAssignmentDTO
    {
        public int AssignmentId { get; set; }
        public int ManagerId { get; set; }
        public int BalanceId { get; set; }
    }
}
