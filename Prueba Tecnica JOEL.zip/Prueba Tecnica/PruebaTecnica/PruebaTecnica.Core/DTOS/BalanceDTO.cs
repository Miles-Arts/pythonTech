﻿namespace PruebaTecnica.Core.DTOS
{
    public class BalanceDTO
    {
        public int BalanceId { get; set; }
        public decimal Balance { get; set; }
    }
}
