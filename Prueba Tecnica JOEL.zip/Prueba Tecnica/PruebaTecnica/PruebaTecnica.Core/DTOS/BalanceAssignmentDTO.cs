﻿namespace PruebaTecnica.Core.DTOS
{
    public class BalanceAssignmentDTO
    {
        public int ManagerId { get; set; }
        public decimal Balance { get; set; }
    }
}
