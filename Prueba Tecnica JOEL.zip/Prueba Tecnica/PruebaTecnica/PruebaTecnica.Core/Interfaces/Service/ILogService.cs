﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PruebaTecnica.Core.Interfaces.Service
{
    public interface ILogService
    {
        public void message(string message);
    }
}
