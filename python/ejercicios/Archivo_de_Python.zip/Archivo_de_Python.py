tamano = float(input())

if 1 <= tamano < 3:
    print("El tornillo es pequeno.")
elif  3 <=  tamano < 5:
    print("El tornillo es mediano.")
elif  5 <=  tamano < 6.5:
    print("El tornillo es grande.")
elif 6.5 <= tamano <= 8.5:
    print("El tornillo es muy grande.")
elif tamano > 8.5 :
        print("El tornillo es gigante.")

else:
    print("El tamano ingresado no es valido." )   


 



