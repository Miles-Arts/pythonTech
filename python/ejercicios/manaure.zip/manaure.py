numero = int(input())

inpar = numero / 2
resultado = inpar % 2

if resultado ==  1 or 21:
    print(f"{numero} es adecuado para apilar.")
else:
    print(f"{numero} no es adecuado para apilar.")














