numero = int(input())

if numero == numero in [6,10,3,15,21]:
    print(f"{numero} es adecuado para apilar.")
else:
    print(f"{numero} no es adecuado para apilar.")