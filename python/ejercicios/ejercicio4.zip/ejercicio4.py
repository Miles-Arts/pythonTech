# Enunciado 
# Tornillo: Cree un programa que solicite el tamaño 
# de un tornillo e imprima su tamaño de acuerdo 
# a las sigueintes condiciones:
# 
# De 1 cm(incluido) hasta 3 cm(no incluido) es pequeño 
# De 3 cm(incluido) hasta 5 cm(no incluido) es mediano 
# De 5 cm(incluido) hasta 6.5 cm(no incluido) es grande 
# de 6.5cm (incluido) hasta 8.5 cm(no incluido) es muy grande 
# De 8.5 cm(incluido) en adelante es gigante


# tamano = float(input("Ingrese el tamaño del tornillo: "))


# if tamano >= 1 and tamano < 3:
#     medida = "El tornillo es pequeno"
# elif tamano >= 3 and tamano < 5:
#     medida = "El tornillo es pequeno"
# elif tamano >= 5 and tamano < 6.5:
#     medida = "El tornillo es pequeno"
# elif tamano >= 6.5 and tamano < 8.5:
#     medida = "El tornillo es muy grande."     
# else:
#     medida = "El tamano ingresado no es valido."    

# print(medida)

# tamanio_tornillo = float(input())

 














tamano = float(input())

if 1 <= tamano < 3:
    print("El tornillo es pequeno.")
elif  3 <=  tamano < 5:
    print("El tornillo es mediano.")
elif  5 <=  tamano < 6.5:
    print("El tornillo es grande.")
elif 6.5 <= tamano <= 8.5:
    print("El tornillo es muy grande.")
elif tamano > 8.5 :
        print("El tornillo es gigante.")

else:
    print("El tamano ingresado no es valido." )   


 



